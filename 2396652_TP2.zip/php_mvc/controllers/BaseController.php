<?php

function base_controller_index()
{

    render("welcome.php");
}
