<div class="container-center">
    <div class="img-forum">
        <img src="resources/img/img-forum.jpg" alt="" width="400px">
    </div>
    <div class="title-page">
        <h1>Welcome to the Maisonneuve College forum</h1>
    </div>
    <div><a href="?controller=user&function=login" class="btn">Login</a> <a href="?controller=user&function=create" class="btn">Create account</a></div>
</div>