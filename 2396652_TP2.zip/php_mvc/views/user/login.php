<div class="title-page">
    <h1>USER login</h1>
</div>
<form action="?controller=user&function=validation" method="post">
    <label for="email">Email:
        <input type="email" id="email" name="email" required></label>

    <label for="password">Password:
        <input type="password" id="password" name="password" required></label>

    <input type="submit" value="Enter" class="btn">
</form>